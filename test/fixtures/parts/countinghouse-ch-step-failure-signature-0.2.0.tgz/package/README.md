# @countinghouse/ch-step-failure-signature

countinghouse step module: a stable fingerprint for a CI failure: the failing step and its error lines, with numbers, paths, times and hashes generalised away.

**Status: preview.** Runs on [countinghouse](https://github.com/mchen6/countinghouse)
8.0 or later (unreleased; the release that carries the remote client and
local mode). A step module of the countinghouse client packs: a `part`, loaded by a scenario and never listed to the model on its own.

Part of the countinghouse client packs. Each package has its own repository; the family's design, plan and acceptance
tests are in [ch-packs](https://github.com/mchen6/ch-packs) (public).

## What it returns

`signatureService.sign` takes ch-step-error-patterns' output and answers:
- `signature`: the sha256 of the step and the normalised error lines;
- `normalised`: those lines;
- `step`: the failing step;
- `algorithm`: the name of the normalisation that made the signature, `fs1` today.

A scenario that caches signatures records `algorithm` and rebuilds its cache
when it changes. Any change to a rule that alters what is signed renames the
algorithm, and a test pins `fs1`'s signature of a fixed input.

## Development

```
npm ci
npm test
npm run validate   # packs the module and runs countinghouse-validate on the tarball
```

Pure JavaScript, no native module. Node 24 or later today (the runtime's
floor); 22.16 once countinghouse's floor shim lands (design). CI runs on
Linux, macOS and Windows.

## Publishing

Releases are published by `.github/workflows/publish.yml` under npm
trusted publishing: a `v<version>` tag on a `main` commit whose
package.json carries that version. No npm token exists anywhere and no 2FA
code is typed for a release. One-time setup on npmjs.com, by the
maintainer: the package's first version is published by hand (`npm publish
--access public`, with 2FA); then **Settings → Trusted publishing → GitHub
Actions** with owner `mchen6`, repository `ch-step-failure-signature`, workflow
`publish.yml`, allowing `npm publish` as well as `npm stage publish`;
then **Settings → Publishing access → Require two-factor authentication
and disallow tokens**. A new trusted-publisher configuration must publish
once within two days or it expires.

## License

Apache-2.0.
